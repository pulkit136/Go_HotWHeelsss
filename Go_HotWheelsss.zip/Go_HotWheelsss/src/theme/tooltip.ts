const baseStyle = {
  px: 3,
  py: 2,
  bg: "gray.900",
  borderRadius: "lg",
};

const styles = {
  baseStyle,
};

export default styles;
