export enum BROWSER_TYPE {
    FIREFOX = 'Firefox',
    CHROME = 'Chrome',
    BRAVE = 'Brave',
    SAFARI = 'Safari',
    UNKNOWN = 'Unknown',
    SAMSUNG = 'Samsung',
    OPERA = 'Opera',
    INTERNETEXPLORER = 'Internet Explorer',
    EDGE = 'Edge'
}