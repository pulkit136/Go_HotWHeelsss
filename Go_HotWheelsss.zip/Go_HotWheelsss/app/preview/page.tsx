"use client";
import React, { FC } from "react"
import { DiscoverPage } from "@/modules/discover";


interface Props {
}

const Page = async (props: Props) => {
    const { } = props;
    return (
        <DiscoverPage />
    )
}

export default Page